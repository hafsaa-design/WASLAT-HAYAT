import 'package:get/get.dart';

class WelcomeController extends GetxController {
  void goToSignUp() {
    Get.toNamed('/signup');
  }

  void goToSignIn() {
    Get.toNamed('/login');
  }
}
