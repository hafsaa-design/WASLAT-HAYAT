import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'signup_controller.dart';

class SignupView extends GetView<SignupController> {
  const SignupView({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF6F6F6),
      appBar: AppBar(
        backgroundColor: const Color(0xFFF6F6F6),
        elevation: 0,
        title: const Text(
          "WASLAT HAYAT",
          style: TextStyle(color: Colors.redAccent),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            const Text(
              "Créer un compte",
              style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 20),

            TextField(
              controller: controller.nameController,
              decoration: const InputDecoration(labelText: "Nom"),
            ),
            const SizedBox(height: 10),

            TextField(
              controller: controller.emailController,
              decoration: const InputDecoration(labelText: "Email"),
            ),
            const SizedBox(height: 10),

            TextField(
              controller: controller.phoneController,
              decoration: const InputDecoration(labelText: "Téléphone"),
            ),

            const SizedBox(height: 10),

            Obx(() => CheckboxListTile(
                  value: controller.agreeTerms.value,
                  onChanged: controller.toggleTerms,
                  title: const Text("J'accepte les conditions"),
                )),

            const SizedBox(height: 10),

            ElevatedButton(
              onPressed: controller.register,
              child: const Text("S'inscrire"),
            ),
          ],
        ),
      ),
    );
  }
}
