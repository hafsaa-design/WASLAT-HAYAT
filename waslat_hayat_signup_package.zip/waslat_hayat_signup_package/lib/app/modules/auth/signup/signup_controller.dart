import 'package:flutter/material.dart';
import 'package:get/get.dart';

class SignupController extends GetxController {
  final nameController = TextEditingController();
  final emailController = TextEditingController();
  final phoneController = TextEditingController();

  var agreeTerms = false.obs;

  void toggleTerms(bool? value) {
    agreeTerms.value = value ?? false;
  }

  void register() {
    if (!agreeTerms.value) {
      Get.snackbar("Erreur", "Veuillez accepter les conditions");
      return;
    }

    Get.snackbar("Succès", "Inscription réussie");
  }

  @override
  void onClose() {
    nameController.dispose();
    emailController.dispose();
    phoneController.dispose();
    super.onClose();
  }
}
