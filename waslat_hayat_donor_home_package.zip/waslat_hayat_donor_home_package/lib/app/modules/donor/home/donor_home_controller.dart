import 'package:get/get.dart';

class DonorHomeController extends GetxController {
  final userName = "Hafsa".obs;
  final userCity = "Laâyoune".obs;
  final bloodGroup = "A+".obs;

  final donationsCount = 3.obs;
  final livesSaved = 8.obs;

  final activities = [
    {
      "title": "Banque de sang",
      "subtitle": "Centres proches",
      "icon": "🏥",
    },
    {
      "title": "Trouver des donneurs",
      "subtitle": "Par groupe sanguin",
      "icon": "🩸",
    },
  ];

  final nearbyRequests = [
    {
      "hospitalName": "Hôpital Hassan II",
      "city": "Laâyoune",
      "urgency": "Urgent",
      "bloodGroup": "O+",
      "image": "assets/images/hospital_request_1.png",
    },
    {
      "hospitalName": "Clinique Al Amal",
      "city": "Laâyoune",
      "urgency": "Moyen",
      "bloodGroup": "A-",
      "image": "assets/images/hospital_request_2.png",
    },
  ];

  final donationConditions = [
    {
      "title": "Âge requis",
      "value": "18 - 65 ans",
      "icon": "📅",
    },
    {
      "title": "Poids requis",
      "value": "50 kg min",
      "icon": "⚖️",
    },
    {
      "title": "Prochain don",
      "value": "56 - 60 jours",
      "icon": "⏰",
    },
    {
      "title": "Taux d'hémoglobine",
      "value": "Normal",
      "icon": "🧪",
    },
  ];

  final bloodTypes = ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"];
  final selectedBloodType = "A+".obs;

  final events = [
    {
      "date": "19 Juil 2025",
      "title": "Campagne de don de sang",
      "location": "Place Al Mechouar, Laâyoune",
      "image": "assets/images/event_1.png",
    },
    {
      "date": "25 Août 2025",
      "title": "Journée de sensibilisation",
      "location": "Centre ville, Laâyoune",
      "image": "assets/images/event_2.png",
    },
  ];

  void selectBloodType(String type) {
    selectedBloodType.value = type;
  }

  String get badgeLabel {
    if (donationsCount.value >= 10) return "Badge Or";
    if (donationsCount.value >= 5) return "Badge Argent";
    return "Badge Bronze";
  }

  String get badgeEmoji {
    if (donationsCount.value >= 10) return "🥇";
    if (donationsCount.value >= 5) return "🥈";
    return "🥉";
  }

  String get canReceiveFrom {
    switch (selectedBloodType.value) {
      case "A+":
        return "A+, A-, O+, O-";
      case "A-":
        return "A-, O-";
      case "B+":
        return "B+, B-, O+, O-";
      case "B-":
        return "B-, O-";
      case "AB+":
        return "Tous les groupes";
      case "AB-":
        return "AB-, A-, B-, O-";
      case "O+":
        return "O+, O-";
      case "O-":
        return "O-";
      default:
        return "-";
    }
  }

  String get canGiveTo {
    switch (selectedBloodType.value) {
      case "A+":
        return "A+, AB+";
      case "A-":
        return "A+, A-, AB+, AB-";
      case "B+":
        return "B+, AB+";
      case "B-":
        return "B+, B-, AB+, AB-";
      case "AB+":
        return "AB+";
      case "AB-":
        return "AB+, AB-";
      case "O+":
        return "O+, A+, B+, AB+";
      case "O-":
        return "Tous les groupes";
      default:
        return "-";
    }
  }
}
