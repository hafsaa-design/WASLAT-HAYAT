import 'package:get/get.dart';
import 'donor_home_controller.dart';

class DonorHomeBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<DonorHomeController>(() => DonorHomeController());
  }
}
