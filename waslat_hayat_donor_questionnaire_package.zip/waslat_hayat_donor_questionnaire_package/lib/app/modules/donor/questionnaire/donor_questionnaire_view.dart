import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'donor_questionnaire_controller.dart';

class DonorQuestionnaireView extends GetView<DonorQuestionnaireController> {
  const DonorQuestionnaireView({super.key});

  InputDecoration _inputDecoration(String hint, {IconData? icon}) {
    return InputDecoration(
      hintText: hint,
      prefixIcon: icon != null ? Icon(icon, color: Colors.grey.shade500) : null,
      filled: true,
      fillColor: Colors.white,
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 18),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: BorderSide(color: Colors.grey.shade300),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: BorderSide(color: Colors.grey.shade300),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: const BorderSide(color: Color(0xFFFF5A5F), width: 1.5),
      ),
    );
  }

  Widget _sectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12, top: 6),
      child: Text(
        title,
        style: const TextStyle(
          fontSize: 18,
          fontWeight: FontWeight.w700,
        ),
      ),
    );
  }

  Widget _yesNoQuestion({
    required String question,
    required RxString value,
  }) {
    return Obx(
      () => Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            question,
            style: const TextStyle(
              fontSize: 15,
              fontWeight: FontWeight.w500,
            ),
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: RadioListTile<String>(
                  value: "Oui",
                  groupValue: value.value,
                  onChanged: (val) => value.value = val ?? '',
                  activeColor: const Color(0xFFFF5A5F),
                  title: const Text("Oui"),
                  contentPadding: EdgeInsets.zero,
                  dense: true,
                ),
              ),
              Expanded(
                child: RadioListTile<String>(
                  value: "Non",
                  groupValue: value.value,
                  onChanged: (val) => value.value = val ?? '',
                  activeColor: const Color(0xFFFF5A5F),
                  title: const Text("Non"),
                  contentPadding: EdgeInsets.zero,
                  dense: true,
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF7F7F7),
      appBar: AppBar(
        backgroundColor: const Color(0xFFF7F7F7),
        elevation: 0,
        title: const Text(
          "WASLAT HAYAT",
          style: TextStyle(
            color: Color(0xFFE53935),
            fontWeight: FontWeight.bold,
          ),
        ),
        iconTheme: const IconThemeData(color: Colors.black),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                "Complétez votre profil de donneur",
                style: TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 10),
              Text(
                "Ces informations nous aideront à mieux vous orienter et à améliorer votre expérience de don.",
                style: TextStyle(
                  fontSize: 16,
                  color: Colors.grey.shade600,
                ),
              ),
              const SizedBox(height: 28),

              _sectionTitle("Informations personnelles"),
              TextField(
                controller: controller.bloodGroupController,
                decoration: _inputDecoration(
                  "Groupe sanguin",
                  icon: Icons.bloodtype_outlined,
                ),
              ),
              const SizedBox(height: 16),

              TextField(
                controller: controller.genderController,
                decoration: _inputDecoration(
                  "Sexe",
                  icon: Icons.person_outline,
                ),
              ),
              const SizedBox(height: 16),

              TextField(
                controller: controller.birthDateController,
                readOnly: true,
                onTap: () => controller.pickBirthDate(context),
                decoration: _inputDecoration(
                  "Date de naissance",
                  icon: Icons.calendar_today_outlined,
                ),
              ),
              const SizedBox(height: 16),

              TextField(
                controller: controller.weightController,
                keyboardType: TextInputType.number,
                decoration: _inputDecoration(
                  "Poids (kg)",
                  icon: Icons.monitor_weight_outlined,
                ),
              ),
              const SizedBox(height: 16),

              TextField(
                controller: controller.cityController,
                decoration: _inputDecoration(
                  "Ville",
                  icon: Icons.location_city_outlined,
                ),
              ),
              const SizedBox(height: 24),

              _sectionTitle("Historique de don"),
              _yesNoQuestion(
                question: "Avez-vous déjà donné votre sang auparavant ?",
                value: controller.hasDonatedBefore,
              ),

              Obx(
                () => controller.hasDonatedBefore.value == "Oui"
                    ? Padding(
                        padding: const EdgeInsets.only(bottom: 20),
                        child: TextField(
                          controller: controller.lastDonationDateController,
                          readOnly: true,
                          onTap: () =>
                              controller.pickLastDonationDate(context),
                          decoration: _inputDecoration(
                            "Date de votre dernier don",
                            icon: Icons.calendar_month_outlined,
                          ),
                        ),
                      )
                    : const SizedBox.shrink(),
              ),

              _sectionTitle("Disponibilité et santé"),
              _yesNoQuestion(
                question: "Êtes-vous actuellement disponible pour répondre aux demandes urgentes ?",
                value: controller.isAvailable,
              ),
              _yesNoQuestion(
                question: "Êtes-vous actuellement en bonne santé ?",
                value: controller.isHealthy,
              ),
              _yesNoQuestion(
                question: "Prenez-vous un traitement médical en ce moment ?",
                value: controller.takesTreatment,
              ),
              _yesNoQuestion(
                question: "Avez-vous subi une opération récente ou une maladie récente ?",
                value: controller.hadRecentOperation,
              ),

              _sectionTitle("Localisation"),
              _yesNoQuestion(
                question: "Autorisez-vous l’accès à votre position pour trouver les demandes proches ?",
                value: controller.allowLocation,
              ),

              const SizedBox(height: 20),

              SizedBox(
                width: double.infinity,
                height: 58,
                child: ElevatedButton(
                  onPressed: controller.submitQuestionnaire,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFFFF5A5F),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16),
                    ),
                    elevation: 0,
                  ),
                  child: const Text(
                    "Continuer",
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.w600,
                      color: Colors.white,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
