import 'package:get/get.dart';
import 'donor_questionnaire_controller.dart';

class DonorQuestionnaireBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<DonorQuestionnaireController>(
      () => DonorQuestionnaireController(),
    );
  }
}
