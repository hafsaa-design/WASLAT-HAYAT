import 'package:flutter/material.dart';
import 'package:get/get.dart';

class DonorQuestionnaireController extends GetxController {
  final bloodGroupController = TextEditingController();
  final genderController = TextEditingController();
  final birthDateController = TextEditingController();
  final weightController = TextEditingController();
  final cityController = TextEditingController();
  final lastDonationDateController = TextEditingController();

  var hasDonatedBefore = ''.obs;
  var isAvailable = ''.obs;
  var isHealthy = ''.obs;
  var takesTreatment = ''.obs;
  var hadRecentOperation = ''.obs;
  var allowLocation = ''.obs;

  Future<void> pickBirthDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime(2000),
      firstDate: DateTime(1950),
      lastDate: DateTime.now(),
    );

    if (picked != null) {
      birthDateController.text =
          "${picked.day.toString().padLeft(2, '0')}/${picked.month.toString().padLeft(2, '0')}/${picked.year}";
    }
  }

  Future<void> pickLastDonationDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(2020),
      lastDate: DateTime.now(),
    );

    if (picked != null) {
      lastDonationDateController.text =
          "${picked.day.toString().padLeft(2, '0')}/${picked.month.toString().padLeft(2, '0')}/${picked.year}";
    }
  }

  void submitQuestionnaire() {
    if (bloodGroupController.text.isEmpty ||
        genderController.text.isEmpty ||
        birthDateController.text.isEmpty ||
        weightController.text.isEmpty ||
        cityController.text.isEmpty ||
        hasDonatedBefore.value.isEmpty ||
        isAvailable.value.isEmpty ||
        isHealthy.value.isEmpty ||
        takesTreatment.value.isEmpty ||
        hadRecentOperation.value.isEmpty ||
        allowLocation.value.isEmpty) {
      Get.snackbar(
        "Attention",
        "Veuillez remplir toutes les informations obligatoires.",
        snackPosition: SnackPosition.BOTTOM,
      );
      return;
    }

    if (hasDonatedBefore.value == "Oui" &&
        lastDonationDateController.text.isEmpty) {
      Get.snackbar(
        "Attention",
        "Veuillez renseigner la date de votre dernier don.",
        snackPosition: SnackPosition.BOTTOM,
      );
      return;
    }

    Get.snackbar(
      "Succès",
      "Profil donneur complété avec succès.",
      snackPosition: SnackPosition.BOTTOM,
    );

    // Change this route if needed in your project.
    // Example: Get.offNamed('/donor-home');
    Get.offNamed('/donor-home');
  }

  @override
  void onClose() {
    bloodGroupController.dispose();
    genderController.dispose();
    birthDateController.dispose();
    weightController.dispose();
    cityController.dispose();
    lastDonationDateController.dispose();
    super.onClose();
  }
}
