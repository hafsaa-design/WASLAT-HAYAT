import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'scanner_controller.dart';

class ScannerView extends GetView<ScannerController> {
  const ScannerView({super.key});

  static const Color primary = Color(0xFFFF3B45);
  static const Color background = Color(0xFFF8F8F8);
  static const Color textColor = Color(0xFF151823);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: background,
      bottomNavigationBar: _bottomNav(),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(22, 18, 22, 24),
          child: Column(
            children: [
              const Text('Scanner', style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold, color: textColor)),
              const SizedBox(height: 12),
              Text(
                'Scannez le QR code après le don pour confirmer votre participation.',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 15, height: 1.45, color: Colors.grey.shade700),
              ),
              const SizedBox(height: 30),
              _scannerBox(),
              const SizedBox(height: 28),
              Obx(() => Container(
                width: double.infinity,
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(22), boxShadow: [
                  BoxShadow(color: Colors.black.withOpacity(0.035), blurRadius: 10, offset: const Offset(0, 4)),
                ]),
                child: Column(children: [
                  Icon(controller.lastCode.value.isEmpty ? Icons.qr_code_2_rounded : Icons.verified_rounded,
                      color: controller.lastCode.value.isEmpty ? Colors.grey : primary, size: 44),
                  const SizedBox(height: 12),
                  Text(controller.scanStatus.value, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: textColor)),
                  if (controller.lastCode.value.isNotEmpty) ...[
                    const SizedBox(height: 8),
                    Text(controller.lastCode.value, style: TextStyle(fontSize: 14, color: Colors.grey.shade700)),
                  ],
                ]),
              )),
              const Spacer(),
              SizedBox(
                width: double.infinity,
                height: 58,
                child: ElevatedButton.icon(
                  onPressed: controller.simulateScan,
                  icon: const Icon(Icons.qr_code_scanner, color: Colors.white),
                  label: const Text('Scanner le code', style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
                  style: ElevatedButton.styleFrom(backgroundColor: primary, elevation: 0, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18))),
                ),
              ),
              const SizedBox(height: 12),
              TextButton(onPressed: controller.resetScan, child: const Text('Réinitialiser', style: TextStyle(color: primary, fontWeight: FontWeight.w600))),
            ],
          ),
        ),
      ),
    );
  }

  Widget _scannerBox() {
    return Container(
      width: 260,
      height: 260,
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(32), boxShadow: [
        BoxShadow(color: primary.withOpacity(0.12), blurRadius: 22, offset: const Offset(0, 8)),
      ]),
      child: Stack(children: [
        Center(child: Icon(Icons.qr_code_2_rounded, size: 160, color: Colors.grey.shade300)),
        Positioned(top: 24, left: 24, child: _corner(true, true)),
        Positioned(top: 24, right: 24, child: _corner(true, false)),
        Positioned(bottom: 24, left: 24, child: _corner(false, true)),
        Positioned(bottom: 24, right: 24, child: _corner(false, false)),
      ]),
    );
  }

  Widget _corner(bool top, bool left) {
    return Container(
      width: 44,
      height: 44,
      decoration: BoxDecoration(border: Border(
        top: top ? const BorderSide(color: primary, width: 4) : BorderSide.none,
        bottom: !top ? const BorderSide(color: primary, width: 4) : BorderSide.none,
        left: left ? const BorderSide(color: primary, width: 4) : BorderSide.none,
        right: !left ? const BorderSide(color: primary, width: 4) : BorderSide.none,
      )),
    );
  }

  Widget _bottomNav() {
    return BottomNavigationBar(
      currentIndex: 2,
      type: BottomNavigationBarType.fixed,
      selectedItemColor: primary,
      unselectedItemColor: Colors.grey,
      items: const [
        BottomNavigationBarItem(icon: Icon(Icons.home_outlined), label: 'Accueil'),
        BottomNavigationBarItem(icon: Icon(Icons.menu_book_outlined), label: 'Culture'),
        BottomNavigationBarItem(icon: Icon(Icons.qr_code_scanner), label: 'Scanner'),
        BottomNavigationBarItem(icon: Icon(Icons.person_outline), label: 'Profil'),
      ],
    );
  }
}
