import 'package:get/get.dart';

class ScannerController extends GetxController {
  final scanStatus = 'Prêt à scanner'.obs;
  final lastCode = ''.obs;

  void simulateScan() {
    lastCode.value = 'DON-WSH-2026-001';
    scanStatus.value = 'Don confirmé avec succès';
  }

  void resetScan() {
    lastCode.value = '';
    scanStatus.value = 'Prêt à scanner';
  }
}
