import 'package:get/get.dart';

class ProfilController extends GetxController {
  final fullName = 'Kawtar El Amrani'.obs;
  final city = 'Casablanca, Maroc'.obs;
  final bloodGroup = 'A+'.obs;

  final donations = 7.obs;
  final livesHelped = 21.obs;
  final badge = 'Or'.obs;

  final personalInfo = [
    {'label': 'Nom complet', 'value': 'Kawtar El Amrani', 'icon': 'person'},
    {'label': 'Téléphone', 'value': '+212 6 12 34 56 78', 'icon': 'phone'},
    {'label': 'Email', 'value': 'kawtar.elamrani@email.com', 'icon': 'email'},
    {'label': 'Date de naissance', 'value': '14 Mars 1998', 'icon': 'calendar'},
    {'label': 'Adresse', 'value': 'Casablanca, Maroc', 'icon': 'location'},
    {'label': 'Groupe sanguin', 'value': 'A+', 'icon': 'blood'},
  ];

  final settings = [
    {'label': 'Notifications', 'value': '', 'icon': 'notifications'},
    {'label': 'Sécurité', 'value': '', 'icon': 'security'},
    {'label': 'Langue', 'value': 'Français', 'icon': 'language'},
    {'label': 'Aide et support', 'value': '', 'icon': 'help'},
    {'label': 'Déconnexion', 'value': '', 'icon': 'logout'},
  ];
}
