import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'profil_controller.dart';

class ProfilView extends GetView<ProfilController> {
  const ProfilView({super.key});

  static const Color primary = Color(0xFFFF3B45);
  static const Color background = Color(0xFFF8F8F8);
  static const Color textColor = Color(0xFF151823);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: background,
      bottomNavigationBar: _bottomNav(),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.only(bottom: 22),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _header(),
              Transform.translate(
                offset: const Offset(0, -34),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _summaryCard(),
                    const SizedBox(height: 18),
                    _sectionTitle('Informations personnelles'),
                    _infoList(controller.personalInfo),
                    const SizedBox(height: 20),
                    _sectionTitle('Paramètres'),
                    _infoList(controller.settings),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _header() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(24, 24, 24, 72),
      decoration: const BoxDecoration(
        gradient: LinearGradient(colors: [Color(0xFFE72F39), Color(0xFFFF5A63)], begin: Alignment.topLeft, end: Alignment.bottomRight),
      ),
      child: Obx(() => Row(
        children: [
          Stack(children: [
            const CircleAvatar(
              radius: 58,
              backgroundColor: Colors.white,
              child: CircleAvatar(radius: 53, backgroundImage: AssetImage('assets/images/profile_kawtar.png')),
            ),
            Positioned(
              right: 0,
              bottom: 4,
              child: Container(
                padding: const EdgeInsets.all(8),
                decoration: const BoxDecoration(color: Colors.white, shape: BoxShape.circle),
                child: const Icon(Icons.edit, color: primary, size: 20),
              ),
            )
          ]),
          const SizedBox(width: 18),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(controller.fullName.value, style: const TextStyle(color: Colors.white, fontSize: 25, fontWeight: FontWeight.bold)),
              const SizedBox(height: 7),
              Row(children: [
                const Icon(Icons.location_on, color: Colors.white, size: 18),
                const SizedBox(width: 4),
                Text(controller.city.value, style: const TextStyle(color: Colors.white, fontSize: 16)),
              ]),
              const SizedBox(height: 10),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
                decoration: BoxDecoration(color: Colors.white.withOpacity(0.95), borderRadius: BorderRadius.circular(18)),
                child: Row(mainAxisSize: MainAxisSize.min, children: [
                  const Icon(Icons.bloodtype, color: primary, size: 19),
                  const SizedBox(width: 5),
                  Text(controller.bloodGroup.value, style: const TextStyle(color: primary, fontSize: 16, fontWeight: FontWeight.bold)),
                  const SizedBox(width: 8),
                  const Text('Groupe sanguin', style: TextStyle(color: Color(0xFF444444), fontSize: 13)),
                ]),
              )
            ]),
          ),
        ],
      )),
    );
  }

  Widget _summaryCard() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 18),
      padding: const EdgeInsets.fromLTRB(18, 18, 18, 22),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(22), boxShadow: [
        BoxShadow(color: Colors.black.withOpacity(0.045), blurRadius: 12, offset: const Offset(0, 5)),
      ]),
      child: Obx(() => Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Mon résumé', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: textColor)),
          const SizedBox(height: 18),
          Row(children: [
            Expanded(child: _statItem(Icons.bloodtype, controller.donations.value.toString(), 'Dons effectués', primary)),
            _divider(),
            Expanded(child: _statItem(Icons.volunteer_activism, controller.livesHelped.value.toString(), 'Vies aidées', primary)),
            _divider(),
            Expanded(child: _statItem(Icons.workspace_premium, controller.badge.value, 'Badge actuel', const Color(0xFFF6A623))),
          ]),
        ],
      )),
    );
  }

  Widget _statItem(IconData icon, String value, String label, Color color) {
    return Column(children: [
      CircleAvatar(radius: 26, backgroundColor: color.withOpacity(0.10), child: Icon(icon, color: color, size: 30)),
      const SizedBox(height: 10),
      Text(value, style: TextStyle(color: color, fontSize: 24, fontWeight: FontWeight.bold)),
      const SizedBox(height: 4),
      Text(label, textAlign: TextAlign.center, style: const TextStyle(fontSize: 13, color: Color(0xFF333333))),
    ]);
  }

  Widget _divider() => Container(width: 1, height: 72, color: const Color(0xFFECECEC));

  Widget _sectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.only(left: 22, right: 22, bottom: 10),
      child: Text(title, style: const TextStyle(fontSize: 21, fontWeight: FontWeight.bold, color: textColor)),
    );
  }

  Widget _infoList(List<Map<String, String>> items) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 18),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18), boxShadow: [
        BoxShadow(color: Colors.black.withOpacity(0.025), blurRadius: 8, offset: const Offset(0, 3)),
      ]),
      child: Column(
        children: items.map((item) {
          final isLast = item == items.last;
          return Column(children: [
            ListTile(
              contentPadding: EdgeInsets.zero,
              leading: Container(
                width: 36,
                height: 36,
                decoration: BoxDecoration(color: const Color(0xFFFFEEEE), borderRadius: BorderRadius.circular(10)),
                child: Icon(_iconFor(item['icon']!), color: primary, size: 20),
              ),
              title: Text(item['label']!, style: const TextStyle(fontSize: 16, color: textColor)),
              trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                if (item['value']!.isNotEmpty) Text(item['value']!, style: TextStyle(fontSize: 15, color: Colors.grey.shade700)),
                const SizedBox(width: 8),
                const Icon(Icons.chevron_right, color: Colors.grey),
              ]),
            ),
            if (!isLast) const Divider(height: 1, thickness: 0.8, indent: 50),
          ]);
        }).toList(),
      ),
    );
  }

  IconData _iconFor(String key) {
    switch (key) {
      case 'person': return Icons.person_outline;
      case 'phone': return Icons.phone_outlined;
      case 'email': return Icons.email_outlined;
      case 'calendar': return Icons.calendar_month_outlined;
      case 'location': return Icons.location_on_outlined;
      case 'blood': return Icons.bloodtype_outlined;
      case 'notifications': return Icons.notifications_none;
      case 'security': return Icons.security_outlined;
      case 'language': return Icons.language;
      case 'help': return Icons.help_outline;
      case 'logout': return Icons.logout;
      default: return Icons.circle_outlined;
    }
  }

  Widget _bottomNav() {
    return BottomNavigationBar(
      currentIndex: 3,
      type: BottomNavigationBarType.fixed,
      selectedItemColor: primary,
      unselectedItemColor: Colors.grey,
      items: const [
        BottomNavigationBarItem(icon: Icon(Icons.home_outlined), label: 'Accueil'),
        BottomNavigationBarItem(icon: Icon(Icons.menu_book_outlined), label: 'Culture'),
        BottomNavigationBarItem(icon: Icon(Icons.qr_code_scanner), label: 'Scanner'),
        BottomNavigationBarItem(icon: Icon(Icons.person), label: 'Profil'),
      ],
    );
  }
}
