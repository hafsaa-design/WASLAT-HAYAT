import 'package:get/get.dart';
import 'conseils_controller.dart';

class ConseilsBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<ConseilsController>(() => ConseilsController());
  }
}
