import 'package:get/get.dart';

class ConseilsController extends GetxController {
  final selectedCategory = 'Toutes'.obs;
  final searchQuery = ''.obs;

  final categories = ['Toutes', 'Don de sang', 'Santé', 'Alimentation', 'Mode de vie'];

  final conseils = [
    {'title': 'Les bienfaits du don de sang', 'subtitle': 'Découvrez comment votre don peut sauver jusqu’à 3 vies.', 'category': 'Don de sang', 'image': 'assets/images/conseil_1.png'},
    {'title': 'Que boire avant et après le don de sang ?', 'subtitle': 'L’hydratation est essentielle pour un don en toute sécurité.', 'category': 'Santé', 'image': 'assets/images/conseil_2.png'},
    {'title': 'Alimentation recommandée pour les donneurs', 'subtitle': 'Les meilleurs aliments à consommer avant de donner votre sang.', 'category': 'Alimentation', 'image': 'assets/images/conseil_3.png'},
    {'title': 'Activités à éviter après le don de sang', 'subtitle': 'Quelques précautions pour votre bien-être après le don.', 'category': 'Mode de vie', 'image': 'assets/images/conseil_4.png'},
    {'title': 'Qui peut donner son sang ?', 'subtitle': 'Conditions et critères pour devenir donneur.', 'category': 'Don de sang', 'image': 'assets/images/conseil_5.png'},
    {'title': 'Le parcours du sang', 'subtitle': 'Découvrez les étapes que suit votre don, de la collecte à la transfusion.', 'category': 'Don de sang', 'image': 'assets/images/conseil_6.png'},
  ];

  List<Map<String, String>> get filteredConseils {
    return conseils.where((item) {
      final categoryOk = selectedCategory.value == 'Toutes' || item['category'] == selectedCategory.value;
      final q = searchQuery.value.toLowerCase().trim();
      final searchOk = q.isEmpty || item['title']!.toLowerCase().contains(q) || item['subtitle']!.toLowerCase().contains(q);
      return categoryOk && searchOk;
    }).map((e) => e.map((key, value) => MapEntry(key, value.toString()))).toList();
  }

  void changeCategory(String category) => selectedCategory.value = category;
  void updateSearch(String value) => searchQuery.value = value;
}
