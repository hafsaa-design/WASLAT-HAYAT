import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'conseils_controller.dart';

class ConseilsView extends GetView<ConseilsController> {
  const ConseilsView({super.key});

  static const Color primary = Color(0xFFFF3B45);
  static const Color background = Color(0xFFF8F8F8);
  static const Color textColor = Color(0xFF151823);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: background,
      bottomNavigationBar: _bottomNav(),
      body: SafeArea(
        child: Column(
          children: [
            const SizedBox(height: 14),
            const Text('Culture', style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold, color: textColor)),
            const SizedBox(height: 18),
            Expanded(
              child: Obx(() => ListView(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
                children: [
                  _searchBar(),
                  const SizedBox(height: 14),
                  _categoryTabs(),
                  const SizedBox(height: 16),
                  ...controller.filteredConseils.map((item) => Padding(
                    padding: const EdgeInsets.only(bottom: 12),
                    child: _conseilCard(item),
                  )),
                ],
              )),
            ),
          ],
        ),
      ),
    );
  }

  Widget _searchBar() {
    return Container(
      height: 52,
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14), border: Border.all(color: const Color(0xFFE5E5E5))),
      child: TextField(
        onChanged: controller.updateSearch,
        decoration: const InputDecoration(
          hintText: 'Rechercher un sujet...',
          hintStyle: TextStyle(color: Colors.grey),
          prefixIcon: Icon(Icons.search, color: Colors.grey),
          border: InputBorder.none,
          contentPadding: EdgeInsets.symmetric(vertical: 15),
        ),
      ),
    );
  }

  Widget _categoryTabs() {
    return SizedBox(
      height: 42,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemCount: controller.categories.length,
        separatorBuilder: (_, __) => const SizedBox(width: 10),
        itemBuilder: (_, index) {
          final category = controller.categories[index];
          final isSelected = controller.selectedCategory.value == category;
          return GestureDetector(
            onTap: () => controller.changeCategory(category),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: isSelected ? primary : Colors.white,
                borderRadius: BorderRadius.circular(13),
                border: Border.all(color: isSelected ? primary : const Color(0xFFE2E2E2)),
              ),
              child: Text(category, style: TextStyle(color: isSelected ? Colors.white : textColor, fontSize: 14, fontWeight: FontWeight.w600)),
            ),
          );
        },
      ),
    );
  }

  Widget _conseilCard(Map<String, String> item) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18), boxShadow: [
        BoxShadow(color: Colors.black.withOpacity(0.035), blurRadius: 10, offset: const Offset(0, 4)),
      ]),
      child: Row(
        children: [
          Container(
            width: 112,
            height: 112,
            decoration: BoxDecoration(
              color: const Color(0xFFFFF0F0),
              borderRadius: BorderRadius.circular(14),
              image: DecorationImage(image: AssetImage(item['image']!), fit: BoxFit.cover),
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(item['title']!, style: const TextStyle(fontSize: 17, height: 1.2, fontWeight: FontWeight.bold, color: textColor)),
              const SizedBox(height: 8),
              Text(item['subtitle']!, style: TextStyle(fontSize: 14, height: 1.35, color: Colors.grey.shade700)),
              const SizedBox(height: 11),
              Row(children: const [
                Text('Lire plus', style: TextStyle(color: primary, fontSize: 15, fontWeight: FontWeight.w600)),
                SizedBox(width: 6),
                Icon(Icons.arrow_forward_ios_rounded, size: 14, color: primary),
              ]),
            ]),
          ),
        ],
      ),
    );
  }

  Widget _bottomNav() {
    return BottomNavigationBar(
      currentIndex: 1,
      type: BottomNavigationBarType.fixed,
      selectedItemColor: primary,
      unselectedItemColor: Colors.grey,
      items: const [
        BottomNavigationBarItem(icon: Icon(Icons.home_outlined), label: 'Accueil'),
        BottomNavigationBarItem(icon: Icon(Icons.menu_book), label: 'Culture'),
        BottomNavigationBarItem(icon: Icon(Icons.qr_code_scanner), label: 'Scanner'),
        BottomNavigationBarItem(icon: Icon(Icons.person_outline), label: 'Profil'),
      ],
    );
  }
}
