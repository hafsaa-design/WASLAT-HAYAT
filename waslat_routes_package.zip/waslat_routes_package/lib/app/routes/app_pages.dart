import 'package:get/get.dart';

// IMPORT PAGES
import '../modules/auth/login/login_view.dart';
import '../modules/donor/home/donor_home_view.dart';
import '../modules/donor/home/donor_home_binding.dart';
import '../modules/donor/questionnaire/donor_questionnaire_view.dart';
import '../modules/donor/questionnaire/donor_questionnaire_binding.dart';

// ROUTES
import 'app_routes.dart';

class AppPages {
  static final routes = [

    GetPage(
      name: AppRoutes.login,
      page: () => const LoginView(),
    ),

    GetPage(
      name: AppRoutes.donorQuestionnaire,
      page: () => const DonorQuestionnaireView(),
      binding: DonorQuestionnaireBinding(),
    ),

    GetPage(
      name: AppRoutes.donorHome,
      page: () => const DonorHomeView(),
      binding: DonorHomeBinding(),
    ),
  ];
}
