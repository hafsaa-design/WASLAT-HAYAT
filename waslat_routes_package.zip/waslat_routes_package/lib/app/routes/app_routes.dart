abstract class AppRoutes {
  static const splash = '/splash';
  static const onboarding = '/onboarding';

  static const login = '/login';
  static const signup = '/signup';

  static const donorQuestionnaire = '/donor-questionnaire';
  static const donorHome = '/donor-home';

  static const profile = '/profile';
  static const conseils = '/conseils';
  static const scanner = '/scanner';
}
