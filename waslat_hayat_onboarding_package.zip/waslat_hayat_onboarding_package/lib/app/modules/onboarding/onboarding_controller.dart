import 'package:flutter/material.dart';
import 'package:get/get.dart';

class OnboardingController extends GetxController {
  final PageController pageController = PageController();

  var currentPage = 0.obs;

  final pages = [
    {
      "image": "assets/images/onboarding1.png",
      "title": "Trouvez des donneurs selon le groupe sanguin",
      "subtitle": "Votre sang peut offrir une seconde chance à quelqu’un."
    },
    {
      "image": "assets/images/onboarding2.png",
      "title": "Donnez du sang, sauvez des vies",
      "subtitle": "Un simple geste peut changer toute une vie."
    },
    {
      "image": "assets/images/onboarding3.png",
      "title": "Rejoignez WASLAT HAYAT",
      "subtitle": "Ensemble, facilitons le don de sang."
    },
  ];

  void onPageChanged(int index) {
    currentPage.value = index;
  }

  void nextPage() {
    if (currentPage.value < pages.length - 1) {
      pageController.nextPage(
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeInOut,
      );
    } else {
      Get.offNamed('/welcome');
    }
  }

  void skip() {
    Get.offNamed('/welcome');
  }

  @override
  void onClose() {
    pageController.dispose();
    super.onClose();
  }
}
